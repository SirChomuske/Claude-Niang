param([switch]$CheckOnly,[string]$UpdateToken)
$ErrorActionPreference='Stop'
$appDir=$PSScriptRoot
. (Join-Path $appDir 'runtime\supervisor-task.ps1')
. (Join-Path $appDir 'runtime\update-common.ps1')
. (Join-Path $appDir 'runtime\install-preflight.ps1')
$config=Get-WidgetInstallPreflight -SourceDir $appDir -AppDir $appDir
if($CheckOnly){@{ok=$true;appDir=$appDir;node=$config.nodePath;startupShortcut=$config.startupShortcut}|ConvertTo-Json;return}
$lock=Enter-WidgetUpdateLock -Token $UpdateToken
try {
  $journal=Read-WidgetUpdateJson (Join-Path (Get-WidgetUpdateAgentDir) 'update-transaction.json')
  if(!$UpdateToken -and $journal -and $journal.phase-notin @('committed','rolled-back')){throw 'Recover the unfinished update before installing.'}
  $config=Get-WidgetInstallPreflight -SourceDir $appDir -AppDir $appDir
  $null=New-Item -ItemType Directory -Path $config.dataDir -Force
  Stop-WidgetSupervisorTask -AppDir $appDir -Configuration $config
  Stop-WidgetGui -AppDir $appDir -DataDir $config.dataDir
  Install-WidgetUpdateAgent $appDir $config.dataDir
  Write-WidgetSupervisorJson (Join-Path $appDir 'installation.json') $config
  # Claude Code feeds the widget through its status line (usage) and a Stop
  # hook (reply finished). Existing settings are backed up and preserved.
  & $config.nodePath (Join-Path $appDir 'runtime\claude-settings.mjs') install $appDir $config.dataDir $config.nodePath
  if($LASTEXITCODE-ne 0){throw 'Could not update Claude Code settings (~/.claude/settings.json).'}
  $link=(New-Object -ComObject WScript.Shell).CreateShortcut($config.startupShortcut)
  # Startup is an independent fallback if the scheduled action cannot run.
  $link.TargetPath=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $link.Arguments=Get-WidgetAgentPowerShellArguments $config.updateAgent
  $link.WorkingDirectory=Join-Path $env:WINDIR 'System32'
  $link.WindowStyle=7
  $link.Description='Claude Niang: Claude desktop pet'
  $link.Save()
  $task=Register-WidgetSupervisorTask -AppDir $appDir
  Write-Output ('Claude Niang '+$config.version+' registered; supervisor started: '+$task.TaskName)
} finally {Exit-WidgetUpdateLock $lock}
