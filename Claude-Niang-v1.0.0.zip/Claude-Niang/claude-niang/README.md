# Claude娘 · 插件与挂件目录

安装、使用和隐私说明请看[项目主页](../README.md)。

- `安装Claude娘.cmd` / `Install.ps1`：检查 Node.js，写入 Claude Code 状态栏与 Stop hook，注册开机启动；`Install.ps1 -CheckOnly` 只检查，不修改系统。
- `停用Claude娘.cmd` / `Uninstall.ps1`：停止挂件并移除本挂件添加的设置。
- `widget.ps1` / `widget.xaml`：Windows WPF 挂件与界面。
- `runtime/statusline.mjs`：Claude Code 状态栏命令（只有终端版会运行），保存 `rate_limits` 的 5 小时与每周窗口。
- `runtime/stop-hook.mjs`：Claude Code Stop hook，记录「回答结束」事件。
- `runtime/claude-settings.mjs`：安装／卸载时修改 `~/.claude/settings.json`（会先备份）。
- `runtime/usage.mjs` / `runtime/watch.mjs`：读取额度快照并刷新挂件。
- `runtime/mcp.mjs`：插件提供的只读 `get_claude_usage` 工具。
- `runtime/supervisor.ps1`：识别 Claude 桌面应用窗口并自动恢复角色。
- `assets/`：两张内置形象、语录、按压音效。

个人数据位于 `%LOCALAPPDATA%\ClaudeNiangUsage\state`，停用后保留。`installation.json` 在安装时生成，不包含在仓库中。

## 许可

代码与文档采用 [MIT License](LICENSE)。角色图片不属于 MIT 授权范围，见 [角色与图片素材声明](assets/CHARACTER-NOTICE.txt)；改写语录见 [语录许可](assets/quotes-LICENSE.txt)。
