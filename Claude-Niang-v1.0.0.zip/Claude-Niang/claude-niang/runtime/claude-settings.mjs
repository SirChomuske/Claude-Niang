// Connects / disconnects the widget in Claude Code's user settings
// (~/.claude/settings.json or $CLAUDE_CONFIG_DIR/settings.json).
//   node claude-settings.mjs install   <appDir> <dataDir> [nodePath]
//   node claude-settings.mjs uninstall <appDir> <dataDir>
//   node claude-settings.mjs status    <appDir> <dataDir>
//
// install (the file is backed up first; every other setting is left alone):
//   hooks.Stop -> runtime/stop-hook.mjs ("reply finished" bubble; works in the
//                 desktop app and the terminal CLI)
//   statusLine -> runtime/statusline.mjs (usage; the terminal CLI runs status
//                 lines, the desktop app does not). An existing status line
//                 command is kept and chained.
// uninstall reverses exactly these entries and restores what was there before.
// Both also remove entries left by the earlier local-proxy experiment
// (env.ANTHROPIC_BASE_URL -> 127.0.0.1, proxy-ensure hooks).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {atomicJson} from './usage.mjs';

const slash=value=>path.resolve(value).replace(/\\/g,'/');
const quote=value=>'"'+value.replace(/"/g,'\\"')+'"';
const HOOK_EVENTS=['Stop','SessionStart','UserPromptSubmit'];

export function settingsFile(env=process.env) {
  const dir=env.CLAUDE_CONFIG_DIR?path.resolve(env.CLAUDE_CONFIG_DIR):path.join(os.homedir(),'.claude');
  return path.join(dir,'settings.json');
}
export function commands(appDir,dataDir,nodePath='node') {
  const node=nodePath==='node'?'node':quote(slash(nodePath));
  const run=script=>`${node} ${quote(slash(path.join(appDir,'runtime',script)))} --data-dir ${quote(slash(dataDir))}`;
  return {statusLine:run('statusline.mjs'),stop:run('stop-hook.mjs')};
}
const ours=command=>typeof command==='string' && (command.includes('claude-niang') || command.includes('ClaudeNiangUsage')) && /(statusline|stop-hook|proxy-ensure)\.mjs/.test(command);
const isProxyUrl=value=>typeof value==='string' && /^http:\/\/127\.0\.0\.1:\d+\/?$/.test(value);

function readSettings(file) {
  if(!fs.existsSync(file))return {};
  const text=fs.readFileSync(file,'utf8').replace(/^﻿/,'');
  if(!text.trim())return {};
  const value=JSON.parse(text); // refuse to touch a file we cannot parse
  if(!value || typeof value!=='object' || Array.isArray(value))throw new Error('settings.json is not a JSON object');
  return value;
}
function withoutOurs(groups) {
  return (Array.isArray(groups)?groups:[])
    .map(group=>({...group,hooks:(Array.isArray(group?.hooks)?group.hooks:[]).filter(hook=>!ours(hook?.command))}))
    .filter(group=>group.hooks.length>0);
}

// Removes the local-proxy entries an earlier version added, restoring the
// base URL the user had before (if any).
function removeLegacyProxy(next,proxyChain) {
  if(next.env && isProxyUrl(next.env.ANTHROPIC_BASE_URL)){
    if(proxyChain?.hadSetting && typeof proxyChain.previous==='string')next.env.ANTHROPIC_BASE_URL=proxyChain.previous;
    else delete next.env.ANTHROPIC_BASE_URL;
    if(!Object.keys(next.env).length)delete next.env;
  }
}

export function applyInstall(settings,{statusLine,stop},files,{proxyChain=null}={}) {
  const next=structuredClone(settings);
  const current=next.statusLine;
  if(current && !ours(current.command) && current.type==='command' && typeof current.command==='string' && current.command.trim())
    atomicJson(files.statusChain,{command:current.command,previous:current,savedAt:new Date().toISOString()});
  next.statusLine={type:'command',command:statusLine};
  if(current && current.padding!==undefined)next.statusLine.padding=current.padding;
  removeLegacyProxy(next,proxyChain);
  next.hooks=next.hooks && typeof next.hooks==='object' && !Array.isArray(next.hooks)?next.hooks:{};
  for(const event of HOOK_EVENTS){
    const kept=withoutOurs(next.hooks[event]);
    if(kept.length)next.hooks[event]=kept;else delete next.hooks[event];
  }
  next.hooks.Stop=[...(next.hooks.Stop ?? []),{hooks:[{type:'command',command:stop,timeout:10}]}];
  return next;
}

export function applyUninstall(settings,{statusChain=null,proxyChain=null}={}) {
  const next=structuredClone(settings);
  if(next.statusLine && ours(next.statusLine.command)){
    if(statusChain?.previous && typeof statusChain.previous==='object')next.statusLine=statusChain.previous;
    else delete next.statusLine;
  }
  removeLegacyProxy(next,proxyChain);
  if(next.hooks && typeof next.hooks==='object'){
    for(const event of HOOK_EVENTS){
      if(!Array.isArray(next.hooks[event]))continue;
      const kept=withoutOurs(next.hooks[event]);
      if(kept.length)next.hooks[event]=kept;else delete next.hooks[event];
    }
    if(!Object.keys(next.hooks).length)delete next.hooks;
  }
  return next;
}

export function status(settings) {
  return {
    statusLine:ours(settings.statusLine?.command),
    legacyProxy:isProxyUrl(settings.env?.ANTHROPIC_BASE_URL),
    hooks:Object.fromEntries(HOOK_EVENTS.map(event=>[event,(settings.hooks?.[event] ?? []).some(g=>(g?.hooks ?? []).some(h=>ours(h?.command)))]))
  };
}

function main() {
  const [action,appDir,dataDir,nodePath]=process.argv.slice(2);
  if(!['install','uninstall','status'].includes(action) || !appDir || !dataDir)throw new Error('usage: claude-settings.mjs install|uninstall|status <appDir> <dataDir> [nodePath]');
  const file=settingsFile();
  const files={statusChain:path.join(dataDir,'statusline-chain.json'),proxyChain:path.join(dataDir,'proxy-chain.json'),proxyConfig:path.join(dataDir,'proxy.json')};
  const settings=readSettings(file);
  if(action==='status'){console.log(JSON.stringify({file,...status(settings)}));return;}
  fs.mkdirSync(dataDir,{recursive:true});
  if(fs.existsSync(file))fs.copyFileSync(file,path.join(dataDir,'claude-settings.backup.json'));
  let next;
  const read=f=>{try{return JSON.parse(fs.readFileSync(f,'utf8'));}catch{return null;}};
  const proxyChain=read(files.proxyChain);
  if(action==='install')next=applyInstall(settings,commands(appDir,dataDir,nodePath||'node'),files,{proxyChain});
  else{
    next=applyUninstall(settings,{statusChain:read(files.statusChain),proxyChain});
    try{fs.unlinkSync(files.statusChain);}catch{}
  }
  // Legacy proxy files: removing proxy.json also lets a still-running old
  // proxy process exit by itself once idle.
  for(const f of [files.proxyChain,files.proxyConfig])try{fs.unlinkSync(f);}catch{}
  atomicJson(file,next);
  console.log(JSON.stringify({ok:true,action,file}));
}

if(process.argv[1] && fileURLToPath(import.meta.url)===path.resolve(process.argv[1]))main();
