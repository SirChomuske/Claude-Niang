import os from 'node:os';
import path from 'node:path';

// Same location the installer uses: %LOCALAPPDATA%\ClaudeNiangUsage\state.
// Hooks and the status line may run from a copied plugin folder, so they
// locate the widget's data by this fixed path (or an explicit override).
export function defaultDataDir(env=process.env) {
  if(env.CLAUDE_NIANG_DATA_DIR)return path.resolve(env.CLAUDE_NIANG_DATA_DIR);
  const local=env.LOCALAPPDATA ?? env.LocalAppData ?? path.join(os.homedir(),'AppData','Local');
  return path.join(local,'ClaudeNiangUsage','state');
}

export function argValue(argv,name) {
  const index=argv.indexOf(name);
  return index>=0 && typeof argv[index+1]==='string' && argv[index+1]?argv[index+1]:null;
}

export function readStdin({maxBytes=4*1024*1024,timeoutMs=3000}={}) {
  return new Promise(resolve=>{
    const chunks=[];let size=0,done=false;
    const finish=()=>{if(done)return;done=true;clearTimeout(timer);resolve(Buffer.concat(chunks).toString('utf8'));};
    const timer=setTimeout(finish,timeoutMs);
    process.stdin.on('data',chunk=>{size+=chunk.length;if(size<=maxBytes)chunks.push(chunk);});
    process.stdin.on('end',finish).on('error',finish);
  });
}
