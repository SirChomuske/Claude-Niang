# Claude Niang has no online updater. These functions remain because the
# widget's timers and menus call them; none of them touch the network.
function Initialize-WidgetUpdater {}
function Test-WidgetUpdateEditor {
  return [bool]($script:audioDialogOpen -or ($script:quoteEditor -and $script:quoteEditor.IsVisible) -or ($script:colorTriggerEditor -and $script:colorTriggerEditor.IsVisible) -or ($script:characterGallery -and $script:characterGallery.IsVisible))
}
function Update-WidgetUpdateMenu {
  if(!$script:settingsMenuUi.UpdateVersion){return}
  $script:settingsMenuUi.UpdateVersion.Header='版本 '+$script:config.version
}
function Tick-WidgetUpdater([long]$Now) {}
