// Claude Code status line command.
// Claude Code pipes session JSON to stdin; for Pro/Max/Ultra subscribers it
// contains `rate_limits.five_hour` / `rate_limits.seven_day`. Only those two
// windows are saved, for the desktop widget to read. Nothing else (prompts,
// paths, session ids, credentials) is stored.
//
// If the user already had a status line, the installer records its command in
// statusline-chain.json and this script runs it with the same input and
// prints its output, so the existing status line keeps working.
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {atomicJson,snapshotPath} from './usage.mjs';
import {defaultDataDir,argValue,readStdin} from './claude-paths.mjs';

const dataDir=path.resolve(argValue(process.argv,'--data-dir') ?? defaultDataDir());
const input=await readStdin();
let data=null;
try{data=JSON.parse(input);}catch{}

const pick=window=>{
  if(!window || typeof window!=='object')return undefined;
  const used=window.used_percentage,reset=window.resets_at;
  if(typeof used!=='number' || !Number.isFinite(used))return undefined;
  return {used_percentage:Math.min(100,Math.max(0,used)),...(typeof reset==='number' && Number.isFinite(reset)?{resets_at:reset}:{})};
};
const limits=data?.rate_limits;
if(limits && typeof limits==='object'){
  const rateLimits={};
  for(const key of ['five_hour','seven_day']){const value=pick(limits[key]);if(value)rateLimits[key]=value;}
  // Claude Code drops a window after it resets; an empty object is still news.
  try{atomicJson(snapshotPath(dataDir),{version:1,capturedAt:Date.now(),claudeVersion:typeof data.version==='string'?data.version.slice(0,40):null,rateLimits});}catch{}
}

function defaultLine() {
  const parts=['Claude娘'];
  const model=data?.model?.display_name;
  if(typeof model==='string' && model)parts.push(model.slice(0,40));
  const left=window=>Math.round(100-window.used_percentage)+'%';
  const five=pick(limits?.five_hour),week=pick(limits?.seven_day);
  if(five)parts.push('5小时 剩'+left(five));
  if(week)parts.push('每周 剩'+left(week));
  return parts.join(' · ');
}

function chained() {
  let chain=null;
  try{chain=JSON.parse(fs.readFileSync(path.join(dataDir,'statusline-chain.json'),'utf8').replace(/^﻿/,''));}catch{}
  const command=typeof chain?.command==='string'?chain.command.trim():'';
  if(!command)return Promise.resolve(null);
  return new Promise(resolve=>{
    let out='',settled=false;
    const finish=value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value);};
    let child;
    try{child=spawn(command,{shell:true,windowsHide:true,stdio:['pipe','pipe','ignore']});}catch{return finish(null);}
    const timer=setTimeout(()=>{try{child.kill();}catch{};finish(out||null);},4000);
    child.stdout.on('data',chunk=>{if(out.length<16384)out+=chunk;});
    child.on('error',()=>finish(null));
    child.on('close',()=>finish(out));
    child.stdin.on('error',()=>{});
    child.stdin.end(input);
  });
}

const previous=await chained();
process.stdout.write(previous!==null?previous:defaultLine());
