import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {quotaWindowLabel} from './plan.mjs';

// Claude Code passes subscription rate limits to its status line command on
// every update. runtime/statusline.mjs saves that block to this file; the
// widget only ever reads it. No credentials, network calls or model calls.
export const SNAPSHOT_FILE='claude-rate-limits.json';
export const snapshotPath=dataDir=>path.join(dataDir,SNAPSHOT_FILE);

const WINDOWS=[['five_hour',300],['seven_day',10080]];
// Status line data has no account identity; one local key keeps the last
// good snapshot when a later read fails.
const ACCOUNT_KEY='claude-code-statusline';
const PLAN={plan:'claude',planLabel:'Claude 订阅',planKnown:true,planSource:'statusline',authType:'claude.ai'};

const resetTime=value=>typeof value==='number' && Number.isFinite(value) && value>0 && value<=253402271999?value:null;
const percent=value=>typeof value==='number' && Number.isFinite(value) && value>=0 && value<=100?value:null;

// Shape the raw status line `rate_limits` object into the widget's windows.
export function normalizeRateLimits(rateLimits,observedAt=Date.now()) {
  const windows=[];let invalid=false;
  if(!rateLimits || typeof rateLimits!=='object' || Array.isArray(rateLimits))invalid=true;
  else for(const [key,minutes] of WINDOWS){
    const raw=rateLimits[key];
    if(raw==null)continue; // Claude Code drops a window once it has reset.
    const used=percent(raw?.used_percentage);
    if(used===null){invalid=true;continue;}
    windows.push({label:quotaWindowLabel(minutes),minutes,used,remaining:100-used,resetsAt:resetTime(raw.resets_at)});
  }
  return {ok:windows.length>0,queryOk:!invalid,source:'statusline',observedAt,...PLAN,windows,accountKey:ACCOUNT_KEY,clearPrevious:false,
    ...(invalid?{errorCode:'INVALID_WINDOWS',error:'Claude Code 额度数据不完整'}:windows.length===0?{errorCode:'NO_WINDOWS',error:'暂无额度窗口，等 Claude Code 下次回复'}:{})};
}

// Signature kept compatible with the worker: (source, options) -> Promise<result>.
export async function readUsage(file,{now=Date.now()}={}) {
  let raw;
  try{raw=fs.readFileSync(file,'utf8');}
  catch(error){
    if(error?.code==='ENOENT')return {ok:false,queryOk:true,...PLAN,windows:[],accountKey:ACCOUNT_KEY,clearPrevious:false,errorCode:'NO_DATA',
      error:'额度需在终端版 Claude Code 中使用后显示'};
    return {ok:false,queryOk:false,...PLAN,windows:[],accountKey:ACCOUNT_KEY,clearPrevious:false,errorCode:'READ_FAILED',error:'额度文件暂时无法读取'};
  }
  let snapshot;
  try{snapshot=JSON.parse(raw.replace(/^﻿/,''));}catch{snapshot=null;}
  const observedAt=Number(snapshot?.capturedAt);
  if(!snapshot || !Number.isFinite(observedAt) || observedAt<=0 || observedAt>now+60000)
    return {ok:false,queryOk:false,...PLAN,windows:[],accountKey:ACCOUNT_KEY,clearPrevious:false,errorCode:'INVALID_SNAPSHOT',error:'额度文件格式不正确'};
  return normalizeRateLimits(snapshot.rateLimits,observedAt);
}

export function atomicJson(file,data) {
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const tmp=file+'.'+process.pid+'.'+randomUUID()+'.tmp';
  try{fs.writeFileSync(tmp,JSON.stringify(data,null,2)+'\n');fs.renameSync(tmp,file);}
  finally{try{fs.unlinkSync(tmp);}catch{}}
}

export function freshness(window,observedAt,now=Date.now()) {
  if(!window || !Number.isFinite(observedAt))return 'unavailable';
  if(Number.isFinite(window.resetsAt) && window.resetsAt>0 && window.resetsAt*1000<=now)return 'expired';
  return now-observedAt>600000?'stale':'fresh';
}
