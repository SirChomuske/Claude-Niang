// Reply-finished monitor for Claude Code.
// runtime/stop-hook.mjs appends one JSON line per finished reply to
// <dataDir>/completion-events.jsonl. This process tails that file and writes
// each new event to stdout for the widget (same line protocol as before).
// Usage: node completion-monitor.mjs <dataDir>/completion-monitor-state.json
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export const EVENTS_FILE='completion-events.jsonl';

export function parseEventLine(line) {
  if(!line || line.length>2048)return null;
  let event;try{event=JSON.parse(line);}catch{return null;}
  if(event?.type!=='completion' || typeof event.sessionId!=='string' || typeof event.turnId!=='string' || !Number.isFinite(event.endedAt))return null;
  return {type:'completion',sessionId:event.sessionId,turnId:event.turnId,endedAt:event.endedAt};
}

export class CompletionMonitor {
  constructor({eventsFile,stateFile=null,intervalMs=500,onNotification=()=>{}}){
    this.eventsFile=eventsFile;this.stateFile=stateFile;this.intervalMs=intervalMs;this.onNotification=onNotification;
    this.offset=null;this.pending='';this.timer=null;
  }
  size(){try{return fs.statSync(this.eventsFile).size;}catch{return 0;}}
  saveState(){if(!this.stateFile)return;try{fs.writeFileSync(this.stateFile,JSON.stringify({offset:this.offset,at:Date.now()}));}catch{}}
  start(){
    // Resume from the saved offset so replies that finished while the widget
    // restarted are still shown; otherwise start at the end of the log.
    let saved=null;
    try{saved=JSON.parse(fs.readFileSync(this.stateFile,'utf8'))?.offset;}catch{}
    const size=this.size();
    this.offset=Number.isSafeInteger(saved) && saved>=0 && saved<=size?saved:size;
    this.scan();
    this.timer=setInterval(()=>this.scan(),this.intervalMs);
  }
  scan(){
    const size=this.size();
    if(size<this.offset){this.offset=0;this.pending='';} // log was restarted
    if(size===this.offset)return;
    let fd;
    try{
      fd=fs.openSync(this.eventsFile,'r');
      const length=Math.min(size-this.offset,256*1024),buffer=Buffer.alloc(length);
      const read=fs.readSync(fd,buffer,0,length,this.offset);
      this.offset+=read;
      const lines=(this.pending+buffer.subarray(0,read).toString('utf8')).split('\n');
      this.pending=lines.pop() ?? '';
      if(this.pending.length>4096)this.pending='';
      for(const line of lines){const event=parseEventLine(line.trim());if(event)this.onNotification(event);}
      this.saveState();
    }catch{}finally{if(fd!==undefined)try{fs.closeSync(fd);}catch{}}
  }
  stop(){if(this.timer)clearInterval(this.timer);this.timer=null;}
}

function run(){
  const stateFile=process.argv[2]||null;
  const dataDir=stateFile?path.dirname(stateFile):process.cwd();
  const monitor=new CompletionMonitor({eventsFile:path.join(dataDir,EVENTS_FILE),stateFile,onNotification:event=>process.stdout.write(JSON.stringify(event)+'\n')});
  monitor.start();process.stdin.resume();
  process.stdin.on('end',()=>{monitor.stop();process.exit(0);});
  process.on('SIGTERM',()=>{monitor.stop();process.exit(0);});
}
if(process.argv[1] && fileURLToPath(import.meta.url)===path.resolve(process.argv[1]))run();
