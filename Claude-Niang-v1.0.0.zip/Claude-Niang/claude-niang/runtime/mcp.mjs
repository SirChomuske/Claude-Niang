import readline from 'node:readline';
import {readUsage,freshness,snapshotPath} from './usage.mjs';
import {defaultDataDir} from './claude-paths.mjs';
import {pluginVersion} from './metadata.mjs';
const send=m=>process.stdout.write(JSON.stringify(m)+'\n');
const tool={name:'get_claude_usage',description:'读取 Claude娘挂件保存的 Claude 订阅额度（5 小时与每周窗口）：已用、剩余百分比、重置时间与数据时间。数据来自 Claude Code 状态栏，只读，不调用模型。',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false}};
const localTime=seconds=>Number.isFinite(seconds) && seconds>0?new Date(seconds*1000).toLocaleString('zh-CN',{hour12:false}):null;
async function handle(m){
  if(!m || typeof m!=='object' || Array.isArray(m) || typeof m.method!=='string'){send({jsonrpc:'2.0',id:null,error:{code:-32600,message:'Invalid Request'}});return;}
  if(m.id===undefined)return;
  try{
    let result;
    switch(m.method){
      case 'initialize': result={protocolVersion:m.params?.protocolVersion??'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'claude-niang-usage',version:pluginVersion}};break;
      case 'ping':result={};break;
      case 'tools/list':result={tools:[tool]};break;
      case 'tools/call':{
        if(m.params?.name!==tool.name)throw new Error('Unknown tool');
        const r=await readUsage(snapshotPath(defaultDataDir()));
        const data={ok:r.ok,queryOk:r.queryOk,source:'Claude Code 状态栏 rate_limits',errorCode:r.errorCode,error:r.error,observedAt:r.observedAt?new Date(r.observedAt).toISOString():null,
          windows:(r.windows??[]).map(w=>({...w,state:freshness(w,r.observedAt),resetLocal:localTime(w.resetsAt)}))};
        result={content:[{type:'text',text:JSON.stringify(data)}],isError:!r.ok || !r.queryOk};break;
      }
      default:send({jsonrpc:'2.0',id:m.id,error:{code:-32601,message:'Method not found'}});return;
    }
    send({jsonrpc:'2.0',id:m.id,result});
  }catch{send({jsonrpc:'2.0',id:m.id,error:{code:-32603,message:'Claude娘额度服务暂不可用，请检查本地安装'}});}
}
readline.createInterface({input:process.stdin}).on('line',line=>{
  if(line.length>1024*1024)return;
  try{void handle(JSON.parse(line));}catch{send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON'}});}
});
