// Claude Code `Stop` hook: Claude has finished responding.
// Appends one small event line for the widget's "reply finished" bubble.
// Only the session id and a timestamp are recorded, never message text.
// Always exits 0 with no output, so it can never block or alter Claude.
import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {defaultDataDir,argValue,readStdin} from './claude-paths.mjs';

export const EVENTS_FILE='completion-events.jsonl';
const MAX_BYTES=64*1024;

async function main() {
  const dataDir=path.resolve(argValue(process.argv,'--data-dir') ?? defaultDataDir());
  let data=null;
  try{data=JSON.parse(await readStdin({maxBytes:1024*1024,timeoutMs:2000}));}catch{}
  if(data?.stop_hook_active===true)return; // a continuation of the same reply
  // Only record when the widget has been installed (its data folder exists).
  if(!fs.existsSync(dataDir))return;
  const sessionId=typeof data?.session_id==='string' && /^[\w-]{1,128}$/.test(data.session_id)?data.session_id:'unknown';
  const file=path.join(dataDir,EVENTS_FILE);
  const line=JSON.stringify({type:'completion',sessionId,turnId:randomUUID(),endedAt:Date.now()})+'\n';
  try{
    // Keep the log small: start over once it grows; the monitor notices the
    // shrink and resumes from the beginning of the new file.
    if(fs.statSync(file).size>MAX_BYTES)fs.writeFileSync(file,'');
  }catch{}
  fs.appendFileSync(file,line);
}

try{await main();}catch{}
process.exit(0);
