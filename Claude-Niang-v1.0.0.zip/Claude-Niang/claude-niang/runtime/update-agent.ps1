param([switch]$Supervisor)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'supervisor-task.ps1')
. (Join-Path $PSScriptRoot 'update-common.ps1')
try {
  $binding=Read-WidgetUpdateJson (Join-Path $PSScriptRoot 'binding.json')
  $null=Assert-WidgetUpdateBinding $binding.appDir $binding.dataDir $PSScriptRoot
  if($Supervisor){& (Join-Path $binding.appDir 'runtime\supervisor.ps1')}
  else {& (Join-Path $binding.appDir 'runtime\start-supervisor.ps1')}
} catch {
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'update-diagnostic.txt'),$_.Exception.ToString(),[Text.UTF8Encoding]::new($false))
  exit 1
}
