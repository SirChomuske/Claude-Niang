# Claude娘（Claude-Niang）

一位捧着书的橙发少女，住在你的桌面上，陪你写代码。

**Windows 桌面宠物 · 中文语录 · 按压音效 · 回答结束提醒 · 终端版 Claude Code 额度显示 · 版本 1.0.0**

<img src="claude-niang/assets/claude-niang-bust.png" alt="Claude娘 形象一" width="220"> <img src="claude-niang/assets/claude-niang-bust-2.png" alt="Claude娘 形象二" width="220">

> 非官方粉丝作品，与 Anthropic 无关联，也未获其认可。“Claude”“Clawd”为 Anthropic 的商标。
> Unofficial fan project. Not affiliated with or endorsed by Anthropic. "Claude" and "Clawd" are trademarks of Anthropic.

## 能做什么

- **点角色看语录**：内置 45 句本小姐语录；点角色打开一句，点气泡换下一句；可在设置里编辑、增加自己的语录，也可开启定时自动说话。
- **按压反馈**：点击角色有挤压（squish）动画和吱吱玩具音效；可在设置中换成自己的 WAV 音效。
- **两张内置形象**：设置菜单 →「更换形象」打开图库，可在两张内置形象之间选择，也能添加电脑上的图片。
- **回答结束提醒**：Claude Code 回答完毕时，气泡提示「Claude 回答完毕啦」（桌面应用和终端都支持；在设置菜单中开启）。
- **跟随窗口或整个桌面**：可只在 Claude 桌面应用窗口内显示，也可在整个桌面自由拖动、缩放、置顶。
- **额度显示（仅终端版 Claude Code）**：使用终端版 Claude Code（CLI）时，点角色可看 5 小时与每周剩余额度、进度条和重置时间。

### 关于额度显示

额度来自 Claude Code 的 **status line（状态栏）** 数据，只有终端版 Claude Code 会运行状态栏。Claude 桌面应用不会运行状态栏，也不会把额度保存在本机，所以只用桌面应用时没有额度数据，Claude娘就作为桌面宠物陪伴你，点击显示语录。

在终端用过 Claude Code 之后，挂件会显示最近一次读到的额度，并标注读取时间；桌面应用和网页版的用量计入同一额度，下次在终端使用时一并更新。

## 需要什么

- Windows 10 / 11
- [Node.js](https://nodejs.org/) 20 或更新版本
- Claude 桌面应用或终端版 Claude Code
- 额度显示需要终端版 Claude Code，并使用 **Claude Pro、Max 或 Ultra** 订阅登录（API Key 用户没有订阅额度数据）

## 安装

1. 下载并完整解压本仓库（或 Release 中的 zip）到一个固定位置，例如 `D:\Apps\Claude-Niang`。安装后不要移动这个文件夹。
2. 进入 `claude-niang` 文件夹，双击 **`安装Claude娘.cmd`**。Windows 可能提示来自网络的文件，选择「仍要运行」。
3. **新开**一个 Claude Code 会话（已打开的会话不会读取新设置）。

安装器会（修改前把 `~/.claude/settings.json` 备份到 `%LOCALAPPDATA%\ClaudeNiangUsage\state\claude-settings.backup.json`）：

- 添加一个 `Stop` hook，用于「回答结束提醒」。
- 设置 status line，用于终端版的额度显示。如果你原本就有状态栏命令，会保留并继续显示它的输出。
- 注册开机启动和一个计划任务，用来启动并守护挂件。

### 可选：安装 Claude Code 插件

插件提供一个只读工具 `get_claude_usage`，让 Claude 读取挂件保存的额度（同样需要终端版的数据）。在 Claude Code 中运行：

```
/plugin marketplace add <本仓库所在路径>
/plugin install claude-niang-usage@claude-niang-local
```

## 隐私

- 状态栏脚本（`runtime/statusline.mjs`）只把 5 小时和每周两个窗口的百分比与重置时间写入 `%LOCALAPPDATA%\ClaudeNiangUsage\state\claude-rate-limits.json`。
- Stop hook（`runtime/stop-hook.mjs`）只记录会话 ID 和时间，不记录对话内容。
- 不读取登录凭据，不联网，不调用模型，不保存提示词、回答、项目路径或会话内容。

## 停用与卸载

双击 `claude-niang\停用Claude娘.cmd`：停止挂件，移除开机启动和计划任务，并从 `settings.json` 中只移除本挂件添加的 hook 和状态栏（原有状态栏会恢复）。个人设置、语录和音效保留在 `%LOCALAPPDATA%\ClaudeNiangUsage`，不需要时可手动删除。

## 自定义

- **语录**：设置菜单 → 我的语录。内置语录在 `claude-niang/assets/quotes.json`，换行排版在 `quote-layouts.json`。
- **音效**：设置菜单 → 音效。支持 5 秒以内的 WAV 文件，可分别设置按下和松开的声音。
- **形象**：设置菜单 → 更换形象，可导入自己的 PNG（建议正方形、透明背景）。

## 目录

```
.claude-plugin/marketplace.json   Claude Code 本地插件市场
claude-niang/
  .claude-plugin/plugin.json      插件清单
  .mcp.json                       get_claude_usage 工具
  安装Claude娘.cmd / 停用Claude娘.cmd / 打开Claude娘.cmd
  widget.ps1, widget.xaml         WPF 桌面挂件
  runtime/statusline.mjs          状态栏（终端版）：保存额度
  runtime/stop-hook.mjs           Stop hook：回答结束提醒
  runtime/claude-settings.mjs     安装 / 卸载时修改 settings.json
  runtime/usage.mjs, watch.mjs    读取额度并刷新挂件
  assets/                         形象、语录、音效
```

## 致谢与许可

- 本项目改编自 [T7moris](https://github.com/T7moris) 的开源桌面挂件项目，原代码采用 MIT License。
- 代码与文档采用 [MIT License](LICENSE)。
- 角色图片不属于 MIT 授权范围，见 [角色与图片素材声明](claude-niang/assets/CHARACTER-NOTICE.txt)。
- 第 15–21 句语录改写自 MeteorNOX 的 MIT 项目，见 [语录许可](claude-niang/assets/quotes-LICENSE.txt)。
- 默认音效改编自用户提供的吱吱玩具音效。
